Thanks for downloading ZM for 3DS (A modpack by TylerSwage)!
THIS MODPACK IS ONLY COMPATIBLE WITH U.S. ENGLISH VERSIONS OF THE GAME (us_en)
This has been in production for over a year now.
ZM is not meant to rival Project: M or replace Project: M for 3DS. It's only becuase I love both things :)
This is one of the only things I do on my free time, plus I have recently gained the responsibilities of having a job. (Other than YT)
Subscribe to my YouTube and follow my Twiiter if you want to stay updated.
YouTube: [https://www.youtube.com/channel/UCj3M9nfOvN6dIEgDJKibD4A]
Twitter: [https://twitter.com/TylerSwage]
Discord Server: [https://discord.gg/6xHWCFT]
If you did not watch the entire video, here are some instructions regarding if you make a video about me or this modpack.
- Link either the modpack VIDEO, or additionally my channel and twitter.
- Make it obivous within the video by saying the modpack is made by me, and tell them to check the description.
- Link me the video on Twitter.
There isn't really a concequence to not following these rules, but it's disrespectful.
--- MODS ---
-- FIGHTERS --
- Luigi -
00 Bubsy
[http://gamebanana.com/skins/155960]
- Little Mac -
03 Doc Louis
[http://gamebanana.com/skins/156196]
- Cloud -
07 FF7 Cloud
[http://gamebanana.com/skins/156253]
-- MUSIC --
/!\ WARNING: Streaming this game can be bad if you have the music enabled, because most fo it will be copyrighted. /!\
- Main Menu -
Tristam - Bone Dry
[Made By me]
-- UI --
All UI Made by me.